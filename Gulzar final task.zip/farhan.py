from flask import Flask, request, redirect, session, render_template_string
import sqlite3

app = Flask(__name__)
app.secret_key = "schoolsecret"

# Initialize database and default admin
def init_db():
    conn = sqlite3.connect("school.db")
    c = conn.cursor()
    # Users table
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )""")
    # Students table
    c.execute("""CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER,
        class TEXT,
        admission_date TEXT,
        marks INTEGER
    )""")
    # Default admin user
    c.execute("INSERT OR IGNORE INTO users (username, password) VALUES (?,?)", ("admin", "Admin@123"))
    conn.commit()
    conn.close()

init_db()

# Dashboard/Home
@app.route("/")
def home():
    if "user" in session:
        conn = sqlite3.connect("school.db")
        c = conn.cursor()
        c.execute("SELECT * FROM students")
        students = c.fetchall()
        conn.close()

        student_rows = ""
        for s in students:
            student_rows += f"<tr><td>{s[1]}</td><td>{s[2]}</td><td>{s[3]}</td><td>{s[4]}</td><td>{s[5]}</td></tr>"

        return render_template_string(f"""
        <html>
        <head>
        <title>School Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        body{{font-family:Arial;background:#f0f2f5;text-align:center;}}
        .box{{background:white;width:90%;margin:auto;padding:20px;border-radius:10px;margin-top:20px;}}
        table{{width:100%;margin-top:20px;border-collapse:collapse;}}
        th,td{{border:1px solid #ddd;padding:8px;}}
        th{{background:#1877f2;color:white;}}
        input{{padding:8px;margin:5px;}}
        button{{padding:8px 15px;background:#1877f2;color:white;border:none;border-radius:5px;}}
        a{{text-decoration:none;color:red;}}
        </style>
        </head>
        <body>
        <h1>🐍 School Management</h1>
        <a href="/logout">Logout</a>

        <div class="box">
            <h3>Add Student</h3>
            <form method="POST" action="/add">
                <input name="name" placeholder="Name" required>
                <input name="age" type="number" placeholder="Age" required>
                <input name="class" placeholder="Class" required>
                <input name="admission_date" type="date" required>
                <input name="marks" type="number" placeholder="Marks" required>
                <button type="submit">Add</button>
            </form>

            <h3>Students List</h3>
            <table>
                <tr><th>Name</th><th>Age</th><th>Class</th><th>Admission Date</th><th>Marks</th></tr>
                {student_rows}
            </table>
        </div>
        </body>
        </html>
        """)
    else:
        return redirect("/login")

# Signup
@app.route("/signup", methods=["GET", "POST"])
def signup():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        try:
            conn = sqlite3.connect("school.db")
            c = conn.cursor()
            c.execute("INSERT INTO users (username, password) VALUES (?,?)",(username,password))
            conn.commit()
            conn.close()
            message = "✅ Signup successful! Please login."
        except:
            message = "❌ Username already exists"

    return render_template_string(f"""
    <html>
    <head>
    <title>Signup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body{{display:flex;justify-content:center;align-items:center;height:100vh;background:#f0f2f5;font-family:Arial;}}
    .box{{background:white;padding:40px;border-radius:10px;width:300px;text-align:center;}}
    input{{width:90%;padding:10px;margin:10px 0;}}
    button{{width:100%;padding:10px;background:green;color:white;border:none;border-radius:5px;}}
    .msg{{color:red;}}
    a{{display:block;margin-top:10px;}}
    </style>
    </head>
    <body>
    <div class="box">
        <h2>Signup</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Signup</button>
        </form>
        <p class="msg">{message}</p>
        <a href="/login">Go to Login</a>
    </div>
    </body>
    </html>
    """)

# Login
@app.route("/login", methods=["GET", "POST"])
def login():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        conn = sqlite3.connect("school.db")
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?",(username,password))
        user = c.fetchone()
        conn.close()
        if user:
            session["user"] = username
            return redirect("/")
        else:
            message = "❌ Wrong Username or Password"

    return render_template_string(f"""
    <html>
    <head>
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body{{display:flex;justify-content:center;align-items:center;height:100vh;background:#f0f2f5;font-family:Arial;}}
    .box{{background:white;padding:40px;border-radius:10px;width:300px;text-align:center;}}
    input{{width:90%;padding:10px;margin:10px 0;}}
    button{{width:100%;padding:10px;background:#1877f2;color:white;border:none;border-radius:5px;}}
    .error{{color:red;}}
    a{{display:block;margin-top:10px;}}
    </style>
    </head>
    <body>
    <div class="box">
        <h2>Login</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p class="error">{message}</p>
        <a href="/signup">Create New Account</a>
    </div>
    </body>
    </html>
    """)

# Add student
@app.route("/add", methods=["POST"])
def add():
    if "user" in session:
        name = request.form.get("name")
        age = request.form.get("age")
        sclass = request.form.get("class")
        date = request.form.get("admission_date")
        marks = request.form.get("marks")
        conn = sqlite3.connect("school.db")
        c = conn.cursor()
        c.execute("INSERT INTO students (name, age, class, admission_date, marks) VALUES (?,?,?,?,?)",
                  (name, age, sclass, date, marks))
        conn.commit()
        conn.close()
        return redirect("/")
    else:
        return redirect("/login")

# Logout
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/login")

if __name__ == "__main__":
    app.run(debug=True)